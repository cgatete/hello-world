%% QUESTION1  
%1.3 ----------------------------------------------------
% Using BlueChipStockMoments� to calculate the correlation matrix
% Correlation matrix is used to find the PCA

load BlueChipStockMoments
% pcacov is used. using corrcov for converting corr cov to correlation matrix and apply pca function.
[COEFF,latent,explained] = pcacov(AssetCovar);
% Changing corr to correlation matrixm
corr_to_correlmatrix = corrcov(AssetCovar);

% Constructing bar graphs to show the weight of each stock for the first and second principal components
rows1 = {'AA','AIG','AXP','BA','C','CAT','DD','DIS','GE','GM','HD','HON','HPQ','IBM','INTC','JNJ','JPM','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','SBC','UTX','VZ','WMT','XOM'};
Col = {'AA','AIG','AXP','BA','C','CAT','DD','DIS','GE','GM','HD','HON','HPQ','IBM','INTC','JNJ','JPM','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','SBC','UTX','VZ','WMT','XOM'};
figure
heatmap(rows1, Col, corr_to_correlmatrix)
title('Bar Graph')
[wcoeff,score,latent1,tsquared,explained1] = pca(corr_to_correlmatrix,'VariableWeights','variance');

% Displaying the bar graph
figure
bar(score(:,1:2))
xticklabels({'AA','AIG','AXP','BA','C','CAT','DD','DIS','GE','GM','HD','HON','HPQ','IBM','INTC','JNJ','JPM','KO','MCD','MMM','MO','MRK','MSFT','PFE','PG','SBC','UTX','VZ','WMT','XOM'})
xlabel('1st Principal Component')
ylabel('2nd Principal Component')
title('Bar graphs showing the weight of each stock for the first and second principal components.')
legend('First Principal Component', 'Second Principal Component')

%QUESTION1.4
% Calculating the amount of variance explained by each principal component and make a �Scree� plot
Latent_1_1 = latent1(1,:);
Latent_1_2 = latent1(2,:);

figure()
pareto(explained1)
xlabel('Principal Component')
ylabel('Variance Explained (%)')
title('Scree plot')

% Needed components to explain 95 percent

num_princ_Comp = 0;
cump = 0;
for(k = 1: size(explained1))
    cump = cump + explained1(k);
    num_princ_Comp = num_princ_Comp +1;
    if(cump >=95)
        break;
    end
end

%QUESTION1.5----------------------------------------------------

PC1 = score(1,:);
PC2 = score(2,:);

figure()
plot(score(:, 1), score(:,2), '+')
text(score(:, 1), score(:,2), rows1);
xlabel('First Principal Component')
ylabel('Second Principal Component')
title('Scatter plot between the First and second components')

% Three most distant stocks

Mean = mean (score(:,1));
[dist,ind] = pdist2(score(:,1), Mean, 'euclidean', 'Largest', 3);

FirstStock = AssetList(ind(1));
secondStock = AssetList(ind(2));
thirdStock = AssetList(ind(3));

% Calculating the average of all 30 stocks

average30 = mean (corr_to_correlmatrix);




%% QUESTION 2
% SubQ 2.3

load BlueChipStockMoments %Loading 'BlueChipStockMoments'

% Calculating the correlation matrix
correlation_Matrix = corrcov(AssetCovar);
% Pairwise distances
Pair_Distance = pdist(correlation_Matrix);
% Small and largest distance
Small_Distance = min(Pair_Distance);
Large_Distance = max(Pair_Distance);

%SubQ2.4----------------------------------------------------

% Constructing a horizontal dendrogram using the average linkage approach, 
% carefully labeling the graphic with the names of the 30 stocks
Dendrogram = linkage(correlation_Matrix,'average');
figure()
% Constructing a dendogram
H = dendrogram(Dendrogram,'Orientation','right','labels',AssetList, 'ColorThreshold','default');
set(H,'LineWidth',2)
title ('Horizontal Dendrogram')
xlabel('Point index')
ylabel('Distance')


%% QUESTION3 
%Sub3.4
% Ensembles for classification
%loading data
Titanic_data = readtable('titanic3.csv');
Passenger_Class_Data = Titanic_data.pclass;
Sex_Data = string(Titanic_data.sex);
Age_Data = Titanic_data.age;
Survived_Data = Titanic_data.survived;
Sex_Data_Double = double(strncmp(Sex_Data, 'female', 3));
Predictors_Data = [Passenger_Class_Data,Sex_Data_Double, Age_Data];

% Constructing a Random forest model

Model_Tree = TreeBagger(50,Predictors_Data,Survived_Data,'oobvarimp','on');
figure
plot(oobError(Model_Tree));
xlabel('The Optimal number Growth of trees'); 
ylabel('Out-of-Bag Classification Error');
title('The Optimal number Growth of trees against Out-of-Bag classification error')


%Sub3.5

% Undertaking a ROC analysis.
idxvar1 = find(Model_Tree.OOBPermutedVarDeltaError>0.75);
b5v = TreeBagger(100,Predictors_Data(:,idxvar1),Survived_Data,'oobpred','on');
gPosition = find(strcmp('1',b5v.ClassNames));
% bPosition = find(strcmp('b',b5v.ClassNames));

[Yfit,Sfit] = oobPredict(b5v);

[fpr,tpr] = perfcurve(b5v.Y,Sfit(:,gPosition),'1');
figure
plot(fpr,tpr, 'r-', 'Linewidth', 1.1)
hold on

%logistic model
X = table(Passenger_Class_Data,Sex_Data_Double, Age_Data, Survived_Data, 'VariableNames',{'pclass','sex','Age','survived'});
linearmodelFit = fitglm(X, 'Distribution', 'binomial', 'Link','logit');
scores = linearmodelFit.Fitted.Probability;

[Xlog,Ylog,T,AUC] = perfcurve(Survived_Data,scores,'1');

plot(Xlog,Ylog, 'g-', 'Linewidth', 1.5)

%KNN model

[N,D] = size(Predictors_Data);
KNN = round(logspace(0,log10(N),10)); % number of neighbors
cvloss = zeros(length(KNN),1);
for k=1:length(KNN)
    % Constructing a cross-validated classification model
    KNNmdl = fitcknn(Predictors_Data,Survived_Data,'NumNeighbors',KNN(k));
    % Calculating the in-sample loss
    rloss1(k)  = resubLoss(KNNmdl);
    % Constructing a cross-validated classifier from the model.
    cRossmdl = crossval(KNNmdl);
    % Examining the cross-validation loss.
    cvloss(k) = kfoldLoss(cRossmdl);
end
[cvlossmin,icvlossmin] = min(cvloss);
kopt = KNN(icvlossmin);

KNN_Model = fitcknn(Predictors_Data,Survived_Data,'NumNeighbors', kopt, 'Distance', 'euclidean', 'ClassNames',{'1', '0'});

% Finding score

[KNNLabel, KNNScore]= resubPredict(KNN_Model);

KNN_Survived = find(strcmp('1',KNN_Model.ClassNames));  

[FPRknn, TPRknn] = perfcurve(categorical(Survived_Data), KNNScore(:,KNN_Survived), '1');

plot(FPRknn,TPRknn, 'b-', 'Linewidth', 1.2)

% Classification tree

Class_tree = fitctree(Predictors_Data, Survived_Data, 'ClassNames',{'1','0'});
[~,score] = resubPredict(Class_tree);
Survived_tree = find(strcmp('1',Class_tree.ClassNames));
[Xtree,Ytree] = perfcurve(categorical(Survived_Data),...
    score(:, Survived_tree),'1');

plot(Xtree,Ytree, 'g-', 'Linewidth', 1.8)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC for Classification by Logistic Regression, Tree, RF and KNN')
legend('Random Forest','Logistic', 'KNN', 'tree', 'Location', 'best')

%% QUESTION4. 
%  Sub4.2

% Reading the data
Red_Wine_Data = readtable('winequality-red.csv');
Quality = Red_Wine_Data.quality;
Predictors_Data = table(Red_Wine_Data.fixedAcidity, Red_Wine_Data.volatileAcidity, Red_Wine_Data.citricAcid, Red_Wine_Data.residualSugar, Red_Wine_Data.chlorides, Red_Wine_Data.freeSulfurDioxide, Red_Wine_Data.totalSulfurDioxide,Red_Wine_Data.density, Red_Wine_Data.pH, Red_Wine_Data.sulphates, Red_Wine_Data.alcohol);

% Constructing Random forest
Model_Random_Forest = TreeBagger(50,Predictors_Data,Quality,'oobvarimp','on');
Predictors_1 = [Red_Wine_Data.fixedAcidity, Red_Wine_Data.volatileAcidity, Red_Wine_Data.citricAcid, Red_Wine_Data.residualSugar, Red_Wine_Data.chlorides, Red_Wine_Data.freeSulfurDioxide, Red_Wine_Data.totalSulfurDioxide,Red_Wine_Data.density, Red_Wine_Data.pH, Red_Wine_Data.sulphates, Red_Wine_Data.alcohol];

% Finding the Optimal Leaf Size
leaf = [1 5 10 20 50 100];
col = 'rgbcmy';
figure

for i=1:length(leaf)
    
    b = TreeBagger(50,Predictors_1,Quality,'method','r','oobpred','on','cat',11,'minleaf',leaf(i));
    plot(oobError(b),col(i));
    hold on;
    
end

xlabel('Number of Grown Trees');
ylabel('Mean Squared Error');
legend({'1' '5' '10' '20' '50' '100'},'Location','NorthEast');
hold off;

title ('Graph showing several number of leaf size');

%Sub4.3
Model_100 = TreeBagger(100,Predictors_1,Quality,'method','r','oobvarimp','on','cat',11,'minleaf',1);
idxvar = find(Model_100.OOBPermutedVarDeltaError>0.7);
b5v = TreeBagger(100,Predictors_Data(:,idxvar),Quality,'method','r','oobvarimp','on','cat',11,'minleaf',1);
figure
plot(oobError(b5v));
xlabel('Number of Grown Trees');
ylabel('Out-of-Bag Mean Squared Error');
title ('Optimal number of trees')

%Sub4.4

% Importance of each feature.
Model_100 = TreeBagger(100,Predictors_Data,Quality,'method','r','oobvarimp','on','cat',11,'minleaf',1);
idxvar = find(Model_100.OOBPermutedVarDeltaError>0.7)
b5v = TreeBagger(100,Predictors_Data(:,idxvar),Quality,'method','r','oobvarimp','on','cat',11,'minleaf',1);

figure
bar(b5v.OOBPermutedVarDeltaError);
feature = {'fixedAcidity', 'volatileAcidity', 'citricAcid', 'residualSugar', 'chlorides', 'freeSulfurDioxide', 'totalSulfurDioxide','density', 'pH', 'sulphates','Alcohol'};
xticklabels(feature)
set(gca, 'xticklabel',feature);
set(gca, 'xticklabelRotation',90)
xlabel('Feature Index');
ylabel('Out-of-Bag Feature Importance');
title('bar graph showing the importance of each feature')

% Comparing with LASSO
Red_Wine_Array = table2array(Red_Wine_Data);
Correlation_RedWine = corrcoef(Red_Wine_Array);

[B,FitInfoRed] = lasso(Predictors_1,Quality,'CV',10);
minpts = find(B(:,FitInfoRed.IndexMinMSE));
lassoPlot(B,FitInfoRed,'PlotType','CV');
legend('show')
% lassoPlot(B,FitInfoRed,'PlotType','Lambda','XScale','log');
% legend('show')

%Sub4.5----------------------------------------------------------------

% Performance of the Random Forest model
MSE = oobError(Model_Random_Forest, 'mode','ensemble')
t = oobPredict(Model_Random_Forest);
y = str2double(t);
ymean = mean(Quality);
N = length(Quality);
Rsqrt= (sum((y-ymean).^2))/N

% Comparing with linear regression
predict = table(Red_Wine_Data.fixedAcidity, Red_Wine_Data.volatileAcidity, Red_Wine_Data.citricAcid, Red_Wine_Data.residualSugar, Red_Wine_Data.chlorides, Red_Wine_Data.freeSulfurDioxide, Red_Wine_Data.totalSulfurDioxide,Red_Wine_Data.density, Red_Wine_Data.pH, Red_Wine_Data.sulphates, Red_Wine_Data.alcohol, Red_Wine_Data.quality);
linearmodel = fitlm(predict);

% For KNN model
% Getting the Kopt

[N,D] = size(Predictors_1);
% Number of neighbors
K = round(logspace(0,log10(N),10)); 
cvloss = zeros(length(K),1);
for k=1:length(K)
    % Constructing a cross-validated classification model
    KNNmdl = fitcknn(Predictors_1,Quality,'NumNeighbors',K(k));
    % Calculate the in-sample loss
    rloss1(k)  = resubLoss(KNNmdl);
    % Construct a cross-validated classifier from the model.
    cRossmdl = crossval(KNNmdl);
    % Examine the cross-validation loss.
    cvloss(k) = kfoldLoss(cRossmdl);
end
[cvlossmin,icvlossmin] = min(cvloss);
kopt = K(icvlossmin);
knnS = fitcknn(Predictors_1,Quality,'Distance','mahalanobis','NumNeighbors', kopt);

% Viewing the performance for KNN
Cvknnl = crossval(knnS);
cvlossM(k) = kfoldLoss(Cvknnl);
